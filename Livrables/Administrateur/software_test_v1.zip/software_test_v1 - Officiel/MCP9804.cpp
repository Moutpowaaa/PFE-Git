#include "MCP9804.h"

// Controle du MCP9804

/* 8 bits d'adresse : 
0011 A2 A1 A0 R/W
A2, A1, A0 : set externally
R/W to 1 for read operation and 0 to write */

// TODO : set des limites

MCP9804::MCP9804()
{
    mpc9804_addr = 0x18;
}

void MCP9804::init()
{
    I2C i2ccom(I2C_SDA, I2C_SCL);
    
    int addr_i2c;
    char cmd[4];
    
    addr_i2c = mpc9804_addr << 1;   // Write operation
    cmd[0] = I2C_REG_TUPPER;
    
    if(LIMITE_TUPPER > 0)
    {
        cmd[1] = LIMITE_TUPPER >> 4;        //0b0000xxxx  Limite max +X°C
    }
    else
    {
        cmd[1] = (LIMITE_TUPPER >> 4) | 0x10;        //0b0001xxxx  Limite max -X°C       
    }
    cmd[2] = (char) LIMITE_TUPPER << 4;  //0bxxxxxx00 Limite max +X°C (on ne prend pas en compte les dixiemes de degres)
    i2ccom.write(addr_i2c, cmd, 3);
    
    addr_i2c = mpc9804_addr << 1;   // Write operation
    cmd[0] = I2C_REG_TLOWER;
    
    if(LIMITE_TLOWER > 0)
    {
        cmd[1] = (LIMITE_TLOWER) >> 4;    //0b0000xxxx Limite max +X°C
    }
    else
    {
        cmd[1] = ((LIMITE_TLOWER) >> 4) | 0x10;    //0b0001xxxx Limite max -X°C
    }
    
    cmd[2] = (char) LIMITE_TLOWER << 4; // 0bxxxxxx00 Limite max -X°C  (on ne prend pas en compte les dixiemes de degres)
    i2ccom.write(addr_i2c, cmd, 3);
    
    addr_i2c = mpc9804_addr << 1;   // Write operation
    cmd[0] = I2C_REG_TCRIT;

    if(LIMITE_TCRIT > 0)
    {
        cmd[1] = (LIMITE_TCRIT) >> 4;    //0b0000xxxx Limite max +X°C
    }
    else
    {
        cmd[1] = ((LIMITE_TCRIT) >> 4) | 0x10;    //0b0001xxxx Limite max -X°C
    }
    
    cmd[2] = (char) LIMITE_TCRIT << 4; // 0bxxxxxx00 Limite max -X°C  (on ne prend pas en compte les dixiemes de degres)
    i2ccom.write(addr_i2c, cmd, 3);
    
    addr_i2c = mpc9804_addr << 1;   // Write operation
    cmd[0] = I2C_REG_RES;
    cmd[1] = 0x00;  // Resolution : 0.5°C
    i2ccom.write(addr_i2c, cmd, 2);
    
    addr_i2c = mpc9804_addr << 1;   // Write operation
    cmd[0] = I2C_REG_CONFIG;
    cmd[1] = 0x02;  // Hysteresis : 1.5°C
    cmd[2] = 0xC8;  // Alert output enable, Tcrit, tupper and tlower locked
    i2ccom.write(addr_i2c, cmd, 3);
}


int MCP9804::getTA()
{
    I2C i2ccom(I2C_SDA, I2C_SCL);
    char cmd[4];
    
    int addr_i2c = mpc9804_addr << 1;   // Write operation
    cmd[0] = I2C_REG_TA;
    i2ccom.write(addr_i2c, cmd, 1);
    
    addr_i2c = (mpc9804_addr << 1) + 1; // Read operation
    i2ccom.read(addr_i2c, cmd, 2);
    
    if((cmd[0] & 0x10) == 0x10) // Si Ta < 0°C
    {
        return cmd[0] * 16 + cmd[1] * 0.0625;
    }
    else
    {
        return 256 - (cmd[0] * 16 + cmd[1] * 0.0625);
    }
}

