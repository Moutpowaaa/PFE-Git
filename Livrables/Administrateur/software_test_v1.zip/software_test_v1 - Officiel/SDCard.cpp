
#include "SDCard.h"
#include <string.h>

SDCard::SDCard(void)
{
    memset(path, 0, 128);  
    SDFileSystem sd(SPI_MOSI, SPI_MISO, SPI_SCLK, SPI_CS_CARTE_SD, SD_CARD_NAME); 
    strcat(path, SD_CARD_NAME);
    strcat(path, "/");
}

int SDCard::open(char * fileName)
{
    mkdir((char *) (*path), 0777);  // On cree le repertoire si besoin
    
    char pathAndName[128];
    strcpy(pathAndName, path);
    strcat(pathAndName, fileName);
    fp = fopen(pathAndName, "w");    // On ouvre en ecriture par defaut

    if(fp == NULL) 
    {
        printf("Could not open file for write\n");
        return -1;
    }
    else
    {
        return 0;
    }
}

void SDCard::close()
{
    fclose(fp);
}

void SDCard::write(char * stringToWrite) 
{   
    fprintf(fp, (char *)(*stringToWrite));
}

SDCard* SDCard::inst;
