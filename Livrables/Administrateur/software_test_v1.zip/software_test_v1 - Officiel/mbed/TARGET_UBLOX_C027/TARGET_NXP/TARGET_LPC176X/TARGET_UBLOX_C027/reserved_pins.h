// List of reserved pins for C027 LPC1768

#ifndef RESERVED_PINS_H
#define RESERVED_PINS_H

#define TARGET_RESERVED_PINS {P3_26}

#endif
