#include "mbed.h"
#include "SDFileSystem.h"

// Paramétrage des pins SPI
#define SPI_MOSI            P1_24
#define SPI_MISO            P1_23
#define SPI_SCLK            P1_20
#define SPI_CS_CARTE_SD     P1_21

#define SD_CARD_NAME        "nameOfSD"

class SDCard
{
public:
 
    SDCard(void);
    static SDCard* getInstance() { return inst; };
    int open(char * fileName);
    void close();
    void write(char * stringToWrite);
    
    
private :
    static SDCard* inst;
    char path[128];
    FILE * fp;
};
