
#include "mbed.h"

// Registres I2C
#define I2C_REG_CONFIG      0x01
#define I2C_REG_TUPPER      0x02
#define I2C_REG_TLOWER      0x03
#define I2C_REG_TCRIT       0x04
#define I2C_REG_TA          0x05
#define I2C_REG_RES         0x08

// Paramétrage des pins I2C
#define I2C_SDA P0_0
#define I2C_SCL P0_1

#define LIMITE_TUPPER      90
#define LIMITE_TLOWER      -20
#define LIMITE_TCRIT       110

class MCP9804
{
public :
    MCP9804(void);
    void init();
    int getTA();
    
private :
    int mpc9804_addr;
};
